#include <iostream>

using namespace std;

main() {

    char a = 100;
    int b = 5212;
    short c = 6123;
    float d = 0.12345;
    double f = 0.1234567890;

    cout << a << endl;
    cout << &a << endl;
    cout << b << endl;
    cout << &b << endl;
    cout << c << endl;
    cout << &c << endl;
    cout << d << endl;
    cout << &d << endl;
    cout << f << endl;
    cout << &f << endl;
}
