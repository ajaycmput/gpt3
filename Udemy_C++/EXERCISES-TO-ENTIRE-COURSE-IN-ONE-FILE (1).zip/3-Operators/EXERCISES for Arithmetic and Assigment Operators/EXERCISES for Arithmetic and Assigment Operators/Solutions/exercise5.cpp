#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, multiplicationResult;

    cout << "This is a simple multiplication program." << endl;
    cout << "Input first number: ";
    cin >> firstElement;
    cout << "Input second number: ";
    cin >> secondElement;

    multiplicationResult = firstElement * secondElement;
    cout << "First number: " << firstElement << endl;
    cout << "Second number: " << secondElement << endl;
    cout << "Multiplication result: " << multiplicationResult << endl;

}


